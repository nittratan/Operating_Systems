// 29. Write a program to perform a tidy exit on receipt of an interrupt signal.

