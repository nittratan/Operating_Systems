
for ((i=$#;i>=1;i--)); 
do 
    echo -n " ${!i} "
done

