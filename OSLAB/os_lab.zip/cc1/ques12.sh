
username='whoami'
grep "^${username}:" /etc/passwd 