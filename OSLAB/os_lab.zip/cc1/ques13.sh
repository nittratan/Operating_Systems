
exec ls -F